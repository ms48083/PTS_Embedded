/*******************************************************************
   REMOTE2.C   Colombo Semi-Automatic Pneumatic Tube Transfer System

   Purpose:    Remote station control program.  Processes local i/o
               and main_station control commands.

   Target:     Z-World BL2500 Rabbit

   Language:   Dynamic C v8.x

   Created:    Jun 12, 2006 by Mike Schwedt (C) MS Technology Solutions

   History:
   12-Jun-06   v301 Original version created from RMOT235.c
   21-Sep-06   v302 skipped version to sync with main
   21-Sep-06   v303 Invert logic state of read-bank inputs
   24-Sep-06   v304 Further refinement of I/O, add InUse/CIC/Flashing
   22-Oct-06   v307 Sync version with Main.  Integrate 4 open-door alerts.
   04-Jan-07   v311 Sync version with Main.  Extend command to 5 data bytes.
   08-Jan-07   v312 Do not invert requestToSend inputs
   10-Jan-07   v313 Setup for using ALL_DEVICES = 0xFF in .devAddr
   14-Jan-07   v314 Integrate turnaround head diverter
   19-Jan-07   v316 Diverter map missing [8] and causing out-of-bounds crash
   24-Jan-07   v318 Continued improvements
   25-Jan-07   v319 Enable TX control a bit sooner to improve communications
                    HD & slave both known at station 8, so ready/not-ready commands now return devAddr
   27-Jan-07   v320 fix bug returning response with device address (THIS_LPLC) -> (THIS_LPLC-1)
                    Clean up implentation & reporting of latched arrival interrupt
   28-Jan-07   v321 Delay response commands to give main time to be ready
   01-Feb-07   v322 Switch from standard blower to heavy duty APU
   03-Feb-07   v323 Initialize blower when starting up head diverter
   11-Feb-07   v326 Handle failure of readDigBank when rn1100 is failed/missing
                    Fix bug in sending arrival status to main
   27-Mar-07   v342 Invert logic state of carrier in chamber and arrival optics
   31-Mar-07   v343 Revert to original logic of CIC and arrival optics
                    Set digital inputs low upon loss of connection to RN1100
   10-Apr-07   v346 Set diverter addr-2 passthrough to port 4 instead of 1
   03-May-07   v347 Delay clearing of arrival latch for 1 second
	04-May-07   v348 Fix handling of latched arrival
   24-May-07   v349 Fix bug in CIC lights not working, no IO Shift
   05-Jun-07   v350 Don't clear latchedCarrierArrival until transaction is complete (remove 1 second clear)
   15-Jul-07   v351 Improve exercise_io so that arrival alert and inuse light up
   					  Report latched arrival only when state is wait_for_remote_arrive
                    Implement feature for remote alternate address request-to-send, to send to master or slave
   23-Jul-07   v352 Implement compile-time selectable blower interface
   25-Jul-07   v353 Bug fix for standard blower in head diverter setup (blwrConfig must equal 1)
   27-Jul-07   v354 Shore up possible weakness in head diverter optic detection
   					  Head diverter arrival optic is on input 0
   31-Jul-07   v355 Don't use interrupt for head diverter, raw arrival input only
   29-Aug-07   v356 DEVELOPMENT VERSION
   29-Dec-07   v365 Released Version - sync w/ main
   					  Get blower selection by main menu setting
                    Get diverter port mapping configuration by main menu setting
                    Support for point to point configuration, remote with one station, no diverter, re-mapped I/O
   13-Apr-08   v366 Support for reporting blower errors
                    Reduce blower timeout to 12 seconds so it happens before carrier lift timeout
	16-Apr-08   v367 Fix mistake in initBlower:   blowerPosition==0 --> blowerPosition()==0
                    Return blowerPosition to the main station for head diverters with APU
   08-Sep-08   v368 Improve robustness of carrier arrival interrupt handling.  Copy from v400.

***************************************************************/
#memmap xmem  // Required to reduce root memory usage
#class auto
#define FIRMWARE_VERSION "REMOTE V3.68"
#define VERSION                     68

// compile as "STANDARD" or "POINT2POINT" remote
#define RT_STANDARD    1
#define RT_POINT2POINT 2
//#define REMOTE_TYPE RT_STANDARD
#define REMOTE_TYPE RT_POINT2POINT

//int lastcommand; // for debug

// define PRINT_ON for additional debug printing via printf
// #define PRINT_ON 1
#use "bl25xx.lib"          Controller library
#use "rn_cfg_bl25.lib"     Configuration library
#use "rnet.lib"            RabbitNet library
#use "rnet_driver.lib"     RabbitNet library
#use "rnet_keyif.lib"      RN1600 keypad library
#use "rnet_lcdif.lib"      RN1600 LCD library

// RabbitNet RN1600 Setup
//int DevRN1600;                    // Rabbit Net Device Number Keypad/LCD
int DevRN1100;                   // Rabbit Net Device Number Digital I/O
//configure to sinking safe state
#define OUTCONFIG 0xFFFF

// Setup interrupt handling for carrier arrival input
// Set equal to 1 to use fast interrupt in I&D space
#define FAST_INTERRUPT 0
char latchCarrierArrival;
void my_isr1();
void arrivalEnable(char how);

// Data structures
#define NUMDATA   5
struct iomessage     /* Communications command structure */
{
   char lplc;
   char command;
   char station;
   char data[NUMDATA];
};
// Including parameter block structure
// Parameters are NOT read to / written from FLASH
struct par_block_type
{  // These parameters are defined on the fly at run-time
   char opMode;      // STD_REMOTE or HEAD_DIVERTER
   char subStaAddressing; // to indicate if substation can select slave for destination
   char blowerType;
   char portMapping;
} param;
#define STD_REMOTE    0
#define HEAD_DIVERTER 1
char mainStation;
#define SLAVE   0x08      // Station number of the slave
#define SLAVE_b 0x80      // Bit representation

char THIS_LPLC;         // board address for communications and setup
char MY_STATIONS;       // to mask supported stations
char IO_SHIFT;          // to map expansion board i/o
char diverter_map[9];   // to assign diverter positions to stations

// Global variables
unsigned long thistime, lasttime, lost;

/* Declare general function prototypes */
void msDelay(unsigned int msec);
char bit2station(char station_b);// station_b refers to bit equivalent: 0100
char station2bit(char station);  // station refers to decimal value: 3 --^
void init_counter(void);
void process_local_io(void);
void set_remote_io(char *remotedata);
void init_io(void);
void exercise_io(void);
void send_response(struct iomessage message);
char get_command(struct iomessage *message);
void process_command(struct iomessage message);
void enable_commands(void);
void arrival_alert(char code, char station);
char isMyStation(char station);
void toggleLED(char LEDDev);
void maintenance(void);
char Timeout(unsigned long start_time, unsigned long duration);
int  readParameterSettings(void);
int  writeParameterSettings(void);

/* Declare local and expansion bus input prototypes */
char carrierInChamber(char station_mask);
char doorClosed(char station_mask);
char carrierArrival(char station_mask);
char requestToSend(char station_mask);
char requestToSend2(char station_mask);
//char diverter_pos(void);

/* Declare local and expansion bus output prototypes */
char rts_latch;      // Used for latching requestToSend
char rts2_latch;     // Used for latching 2nd requestToSend (to slave)
void inUse(char how, char station_b);
void alert(char how, char station_b);
void alarm(char how);
// void diverter(char how);
void setDiverter(char station);
void processDiverter(void);
void setDiverterMap(char portMap);

// Declare watchdog and powerlow handlers
char watchdogCount(void);
char powerlowCount(void);
void incrementWDCount(void);
void incrementPLCount(void);
void loadResetCounters(void);

// Digital I/O definitions
char outputvalue [6];   // buffer for some outputs
char remoteoutput [5];  // buffer for main commanded outputs
// INPUTS
int readDigInput(char channel);
int readDigBank(char bank);  // banks 0,1 on Coyote; banks 2,3 on RN1100
// dio_ON|OFF must be used ONLY in primatives readDigInput and setDigOutput
// they reflect the real state of the logic inputs and outputs
#define dio_ON  0
#define dio_OFF 1
#define di_HDArrival					  readDigInput(0)
// Check for and setup point to point configuration
#if REMOTE_TYPE == RT_POINT2POINT
	#warnt "Compiling as point-to-point configuration"
	#define di_carrierArrival          readDigInput(0)
	#define di_requestToSend           readDigInput(1)
	#define di_requestToSend2          0
	#define di_doorClosed              readDigInput(2)
	#define di_carrierInChamber        readDigInput(3)
#else
	#define di_carrierArrival          (((readDigBank(0)) & 0x1E) >> 1)
	#define di_carrierInChamber        (((readDigBank(1)) & 0xF0) >> 4)
	#define di_requestToSend           (readDigBank(2) & 0x0F)
	#define di_requestToSend2          (readDigBank(3) & 0x0F)
	#define di_doorClosed              ((readDigBank(2) & 0xF0) >> 4)
#endif
#define di_remoteAddress           ((readDigBank(0) & 0xE0) >> 5)
#define di_diverterPos             (readDigBank(1) & 0x0F)
#define di_shifterPosIdle          readDigInput(12)
#define di_shifterPosPrs           readDigInput(13)
#define di_shifterPosVac           readDigInput(14)

// OUTPUTS
void setDigOutput(int channel, int value);
#define do_shift 0
// Check for and setup point to point configuration
#if REMOTE_TYPE == RT_POINT2POINT
	#define do_doorAlert(which,value)    setDigOutput(0,value)
	#define do_arrivalAlert(which,value) setDigOutput(1,value)
	#define do_CICLight(which,value)     setDigOutput(2,value)
	#define do_inUseLight(which,value)   setDigOutput(3,value)
   // inUseLight on output 3,4,7 causes RS485 transmitter to enable (PA4)
   // Root cause was use of static CHAR elements in maintenance() instead of static INT
#else
	#define do_doorAlert(which,value)    setDigOutput(0+do_shift+which,value)
	#define do_arrivalAlert(which,value) setDigOutput(8+do_shift+which,value)
	#define do_inUseLight(which,value)   setDigOutput(12+do_shift+which,value)
	#define do_inUse2Light(which,value)  setDigOutput(20+do_shift+which,value)
	#define do_CICLight(which,value)     setDigOutput(16+do_shift+which,value)
#endif
#define do_diverter(value)           setDigOutput(4+do_shift,value)
//#define do_alarm(value)              setDigOutput(xx+do_shift,value)
#define do_blower(value)             setDigOutput(5+do_shift,value)
#define do_blowerVac(value)          setDigOutput(6+do_shift,value)
#define do_blowerPrs(value)          setDigOutput(7+do_shift,value)


#define ALARM_MASK           0x20
// #define beep(value)                rn_keyBuzzerAct(DevRN1600, value, 0)
void inUse(char how, char station_b);
void inUse2(char how, char station_b);
void alarm(char how);

/* "how" types & values and other constants */
#define ON           0xFF
#define OFF          0x00
#define FLASH        0x01
#define READY        0x01
#define NOT_READY    0xFF
//#define TRUE         0xFF
//#define FALSE        0x00
#define aaRESET      0x00
#define aaSET        0x01
#define aaTEST       0x02
#define ToREMOTE     0x01
#define ToMAIN       0x02
#define ALL_DEVICES  0xFF

/* Serial communications send and receive commands */
#define NAK 0x15
#define ACK 0x06
#define STX 0x02
#define ETX 0x03
#define DINBUFSIZE 63
#define DOUTBUFSIZE 63
#define SET_DIVERTER       'A'
#define DIVERTER_STATUS    'B'
#define DIVERTER_READY     'C'
#define DIVERTER_NOT_READY 'D'
#define RETURN_INPUTS      'E'
#define INPUTS_ARE         'E'
#define SET_OUTPUTS        'G'
#define CLEAR_OUTPUTS      'H'
#define SET_OPMODE         'I'
#define ARE_YOU_READY      'J'
#define RETURN_EXTENDED    'K'
#define SET_TRANS_COUNT    'L'
#define SET_DATE_TIME      'M'
#define SET_STATION_NAME   'N'
#define CANCEL_PENDING     'O'
#define TAKE_COMMAND       'P'
#define DISPLAY_MESSAGE    'Q'
#define SET_PHONE_NUMS     'R'
#define SET_PARAMETERS     'S'
#define TRANS_COMPLETE     'X'
#define RESET              'Y'
#define MALFUNCTION        'Z'

// Define all system states - MUST BE IDENTICAL TO MAIN
#define  IDLE_STATE             0x01
#define  PREPARE_SEND           0x02
#define  WAIT_FOR_DIVERTERS     0x03
#define  BEGIN_SEND             0x04
#define  WAIT_FOR_MAIN_DEPART   0x05
#define  WAIT_FOR_REM_ARRIVE    0x06
#define  HOLD_TRANSACTION       0x07
#define  WAIT_FOR_REM_DEPART    0x08
#define  WAIT_FOR_MAIN_ARRIVE   0x09
#define  WAIT_FOR_TURNAROUND    0x0A
#define  SHIFT_TURNAROUND       0x0B
#define  CANCEL_STATE           0x0C
#define  MALFUNCTION_STATE      0x0D
#define  FINAL_COMMAND          0x0E

// Define transaction direction constants
#define  DIR_SEND             1
#define  DIR_RETURN           2

// Declare blower interfaces
#define blwrType_STD  1
#define blwrType_APU  2
// change blwrType for the type of blower being used
//#define blwrType blwrType_STD
#define blwrOFF  0
#define blwrIDLE 1
#define blwrVAC  2
#define blwrPRS  3
char blwrConfig; // later to become parameter from eeprom
char blwrError;
void blower(char blowerOperatingValue);  // use blwrOFF, blwrIDLE, blwrVAC, blwrPRS
char processBlower(void);
char blowerPosition(void);
void initBlower(void);

// Blower state is based on system_state -> [system_state][blwrConfig]
// blwrConfig in remote systems is always 1 for head diverter.
// No remote configuration uses a blwrConfig of 0
// Independent of blower type standard or APU
const char blowerStateTable[15][2] = {
   blwrOFF,  blwrOFF,    // Undefined state 0
   blwrIDLE, blwrIDLE,  // 0x01 (Idle)
   blwrIDLE, blwrIDLE,  // 0x02
   blwrIDLE, blwrIDLE,  // 0x03
   blwrIDLE, blwrIDLE,  // 0x04
   blwrPRS,  blwrVAC,   // 0x05 (Main departure)
   blwrPRS,  blwrPRS,   // 0x06 (Remote arrival)
   blwrIDLE, blwrIDLE,  // 0x07
   blwrVAC,  blwrVAC,   // 0x08 (Remote departure)
   blwrVAC,  blwrPRS,   // 0x09 (Main arrival)
   blwrIDLE, blwrVAC,   // 0x0A (Wait for turnaround)
   blwrIDLE, blwrIDLE,  // 0x0B
   blwrIDLE, blwrIDLE,  // 0x0C
   blwrOFF,  blwrOFF,   // 0x0D
   blwrIDLE, blwrIDLE };// 0x0E

/* Declare miscellaneous timeouts */
#define DIVERTER_TIMEOUT  30000        // How long to set diverter
                   // May be longer than mainsta timeout
/******************************************************************/
char arrival_from;          // indicates if main is ready for receive or in arrival alert

/* Array index values for remote data, returned by INPUTS_ARE command. */
#define REMOTE_CIC      0
#define REMOTE_DOOR     1
#define REMOTE_ARRIVE   2
#define REMOTE_RTS      3
#define REMOTE_RTS2     4

main()
{  int i;
   unsigned long timeout;
   struct iomessage message;
   char key, simonsays;
   auto rn_search newdev;
   int status;

   /* Initialize i/o */
   loadResetCounters();  // load counters for watchdog and powerlow resets
   // Initialize the controller
   brdInit();              // Initialize the controller
   rn_init(RN_PORTS, 1);   // Initialize controller RN ports

   // Check if Rabbitnet boards are connected
   newdev.flags = RN_MATCH_PRDID;
   newdev.productid = RN1100;
   if ((DevRN1100 = rn_find(&newdev)) == -1)
   {
      printf("\n no RN1100 found\n");
   }
   else status = rn_digOutConfig(DevRN1100, OUTCONFIG);  //configure safe state

   // check if last reset was due to watchdog
   //if (wderror()) incrementWDCount();

   hitwd();
   init_io();
   arrival_alert(aaRESET, 0);
   toggleLED(255);  // initialize LED outputs
	readParameterSettings();

   /* read board address and set configuration i/o mappings */
   THIS_LPLC = (di_remoteAddress);
   //if (PRINT_ON) printf("\nThis is remote plc # %d", THIS_LPLC);

   // Check for and setup point to point configuration
   #if REMOTE_TYPE == RT_POINT2POINT
		THIS_LPLC = 1;
   #endif

   // flash the plc number
   //flasher(0);
   for (i=0; i<THIS_LPLC; i++)
   {  msDelay(200);
      ledOut(0,1);
      msDelay(150);
      ledOut(0,0);
      hitwd();
   }
   // if (PRINT_ON) printf("\nWD and PL Reset Counters %d  %d", watchdogCount(), powerlowCount());
   exercise_io();

   // Set the diverter mapping based on the Remote ID#
   setDiverterMap(param.portMapping);

   // setup interrupt handler for arrival optics
   #if __SEPARATE_INST_DATA__ && FAST_INTERRUPT
      interrupt_vector ext1_intvec my_isr1;
   #else
      SetVectExtern3000(1, my_isr1);
      // re-setup ISR's to show example of retrieving ISR address using GetVectExtern3000
      //SetVectExtern3000(1, GetVectExtern3000(1));
   #endif
   // WrPortI(I1CR, &I1CRShadow, 0x09);      // enable external INT1 on PE1, rising edge, priority 1
   arrivalEnable(FALSE);  // Disable for now

   /* Initialize serial port 1 */
   enable_commands();

   thistime=MS_TIMER;
   lost=0;

   simonsays=TRUE;
   while(simonsays)
   {  // loop forever

      maintenance();  // Hit WD, flash LEDs, write outputs

      /* check for and process incoming commands */
      if (get_command(&message)) process_command(message);

      /* check for and process local inputs */
      process_local_io();
      arrival_alert(aaTEST, 0);

   } /* end while */
}
/********************************************************/
char trans_station, diverter_station;
char carrier_attn, carrier_attn2;
char system_state;
/********************************************************/
unsigned long arrivalDuration;
char arrivalISRstate;
#define AISR_RISING 1
#define AISR_FALLING 2
nodebug root interrupt void my_isr1()
{
/*
   latchCarrierArrival=TRUE;
   //whichCA=di_carrierArrival; //carrierArrival(255);
   WrPortI(I1CR, &I1CRShadow, 0x00);      // disble external INT1 on PE1
*/
	// New concept ...
   // arrivalEnable sets up for falling edge interrupt
   // Detect that here and then reverse setup to detect rising edge
   // Once rising edge detected then validate duration
   // If duration is good (> x ms) then latch and disable interrupt
   // Otherwise reset interrupt for rising edge since it was previously active
	if (arrivalISRstate == AISR_FALLING)  // Carrier has entered optic zone
   {  // Setup to detect rising edge
		WrPortI(I1CR, &I1CRShadow, 0x0A);
      arrivalDuration = MS_TIMER;
      arrivalISRstate = AISR_RISING;
   } else if (arrivalISRstate == AISR_RISING) // Carrier has left optic zone
   {  //
		WrPortI(I1CR, &I1CRShadow, 0x00);  // disable interrupt
      arrivalDuration = MS_TIMER - arrivalDuration;
      arrivalISRstate = 0;  // No more activity
      if (arrivalDuration > 10) latchCarrierArrival=TRUE;  // Got a good arrival
      // note: 10 ms pulse for a 12 inch carrier is 100 FPS or 61.4 MPH
      else
      {  WrPortI(I1CR, &I1CRShadow, 0x06);  // Too short, reset for another try
         arrivalISRstate = AISR_FALLING;
      }
   }
}
void arrivalEnable(char how)
{
   // should call this routine once to enable interrupt and once to disable

   #GLOBAL_INIT
   {
      latchCarrierArrival=FALSE;
   }

   latchCarrierArrival=FALSE;    // clear existing latch
   if (how)
   {	// enable  INT1
   	WrPortI(I1CR, &I1CRShadow, 0x06);		// enable external INT1 on PE1, falling edge, priority 2
      arrivalISRstate = AISR_FALLING;
   } else
   {  // disable INT1
      WrPortI(I1CR, &I1CRShadow, 0x00);      // disble external INT1 on PE1
      arrivalISRstate = 0;
   }
}

void setDiverterMap(char portMap)
{	// Sets up the diverter port mapping based on the supplied parameter
	// Also sets the parameter opMode to standard or head-diverter
   // Entry in diverter_map is the binary diverter port number (1,2,4,8)
   param.opMode = STD_REMOTE;
   switch (portMap)
   {
      case 0:
         break;
      case 1:
         MY_STATIONS = 0x0F;     // mask for stations used by this lplc
         IO_SHIFT = 0;           // 4 for stations 5-7, 0 for stations 1-3
         diverter_map[0] = 0; diverter_map[1] = 1;
         diverter_map[2] = 2; diverter_map[3] = 4;
         diverter_map[4] = 8; diverter_map[5] = 0;
         diverter_map[6] = 0; diverter_map[7] = 0;
         diverter_map[8] = 0; // for main to main
	      // Check for and setup point to point configuration
	      #if REMOTE_TYPE == RT_POINT2POINT
	         MY_STATIONS = 0x01;     // mask for stations used by this lplc
	         diverter_map[2] = 0; diverter_map[3] = 0; diverter_map[4] = 0;
         #endif
         break;
      case 2:
         MY_STATIONS = 0x70;     // mask for stations used by this lplc
         IO_SHIFT = 4;           // 4 for stations 5-7, 0 for stations 1-3
         diverter_map[0] = 0; diverter_map[1] = 8;
         diverter_map[2] = 8; diverter_map[3] = 8;
         diverter_map[4] = 8; diverter_map[5] = 1;
         diverter_map[6] = 2; diverter_map[7] = 4;
         diverter_map[8] = 0; // for main to main
         break;
      case 3:
         MY_STATIONS = 0x03;     // mask for stations used by this lplc
         IO_SHIFT = 0;           // maps i/o 1-4 to stations x-x
         diverter_map[0] = 0; diverter_map[1] = 1;
         diverter_map[2] = 2; diverter_map[3] = 4;
         diverter_map[4] = 4; diverter_map[5] = 8;
         diverter_map[6] = 8; diverter_map[7] = 8;
         diverter_map[8] = 0; // for main to main
         break;
      case 4:
         MY_STATIONS = 0x0C;     // mask for stations used by this lplc
         IO_SHIFT = 2;           // maps i/o 1-4 to stations x-x
         diverter_map[0] = 0; diverter_map[1] = 0;
         diverter_map[2] = 0; diverter_map[3] = 1;
         diverter_map[4] = 2; diverter_map[5] = 0;
         diverter_map[6] = 0; diverter_map[7] = 0;
         diverter_map[8] = 0; // for main to main
         break;
      case 5:
         MY_STATIONS = 0x70;     // mask for stations used by this lplc
         IO_SHIFT = 4;           // maps i/o 1-4 to stations x-x
         diverter_map[0] = 0; diverter_map[1] = 0;
         diverter_map[2] = 0; diverter_map[3] = 0;
         diverter_map[4] = 0; diverter_map[5] = 1;
         diverter_map[6] = 2; diverter_map[7] = 4;
         diverter_map[8] = 0; // for main to main
         break;
      case 6:
         MY_STATIONS = 0x01;     // mask for stations used by this lplc
         IO_SHIFT = 0;           // maps i/o 1-4 to stations x-x
         diverter_map[0] = 0; diverter_map[1] = 1;
         diverter_map[2] = 2; diverter_map[3] = 2;
         diverter_map[4] = 2; diverter_map[5] = 2;
         diverter_map[6] = 2; diverter_map[7] = 2;
         diverter_map[8] = 0; // for main to main
         break;
      case 7:  // HEAD DIVERTER USE ONLY
         param.opMode = HEAD_DIVERTER;
         MY_STATIONS = 0x80;     // mask for stations used by this lplc
         IO_SHIFT = 0;           // maps i/o 1-4 to stations x-x
         diverter_map[0] = 0; diverter_map[1] = 1;
         diverter_map[2] = 2; diverter_map[3] = 4;
         diverter_map[4] = 0; diverter_map[5] = 0;
         diverter_map[6] = 0; diverter_map[7] = 0;
         diverter_map[8] = 0; // for main to main
         initBlower();  // only head diverter uses a blower
         break;
      default:   // any other undefined selection
         MY_STATIONS = 0x00;     // mask for stations used by this lplc
         IO_SHIFT = 0;           // maps i/o 1-4 to stations x-x
         diverter_map[0] = 0; diverter_map[1] = 0;
         diverter_map[2] = 0; diverter_map[3] = 0;
         diverter_map[4] = 0; diverter_map[5] = 0;
         diverter_map[6] = 0; diverter_map[7] = 0;
         diverter_map[8] = 0; // for main to main
         break;
   }
}

void init_io()
{
   char i;
   for (i=0; i<4; i++)          // four or five output ports
   {
      outputvalue[i] = 0;
      remoteoutput[i] = 0;
   }
   blower(blwrOFF);
   alarm(OFF);
}
void exercise_io()
{
//   if (!wderror())
//   {
      alert(ON, MY_STATIONS);
      inUse(ON, MY_STATIONS);
      inUse2(ON, MY_STATIONS);
      maintenance(); msDelay(1000); maintenance(); msDelay(1000);
      //inUse(ON, MY_STATIONS); maintenance(); msDelay(200);
      inUse(OFF, MY_STATIONS); inUse2(OFF, MY_STATIONS); alert(OFF, MY_STATIONS);
      maintenance(); msDelay(200);

      inUse(ON, MY_STATIONS); inUse2(ON, MY_STATIONS); alert(ON, MY_STATIONS);
      maintenance(); msDelay(200);
//   }
   inUse(OFF, MY_STATIONS);
   inUse2(OFF, MY_STATIONS);
   alert(OFF, MY_STATIONS);
	maintenance();
   hitwd();       // hit the watchdog

}
/********************************************************/
void process_local_io()
{
   char rts_data, rts2_data, cic_data;  /* bitwise station bytes */
   char door_closed;
   char on_bits, flash_bits;  /* which ones on and flash */
   char on_bits2, flash_bits2;  /* which ones on and flash for 2nd in-use light */
   char s, sb;                /* work vars for station & stationbit */
   char i;
   //static unsigned long LA_Timer;  // to latch the arrival signal

   #GLOBAL_INIT
   {
      rts_latch=0;
      rts2_latch=0;
      trans_station=0;
      diverter_station=0;
      carrier_attn=0;
      carrier_attn2=0;
      //arrival_time=0;
      arrival_from=0;
      //LA_Timer=0;
      mainStation=0;
      param.subStaAddressing=FALSE;
   }

   /* Check for diverter and blower attention */
   processDiverter();
   processBlower();

   /* Use local buffers for some inputs */
   if (param.opMode == STD_REMOTE)
   {  // stuff for standard remote inputs
      rts_data=requestToSend(MY_STATIONS);
      rts2_data=requestToSend2(MY_STATIONS);
      cic_data=carrierInChamber(MY_STATIONS);
      door_closed=doorClosed(MY_STATIONS);

      // handle carrier in chamber light
      // Need to shift CIC input back to (1..4) range for correct output
      // Check for and setup point to point configuration
      #if REMOTE_TYPE == RT_POINT2POINT
      	do_CICLight(0, (cic_data>>IO_SHIFT) & 1);
      #else
	      for (i=0; i<4; i++) do_CICLight(i, (cic_data>>IO_SHIFT) & (1<<i));
  	   #endif

      /* Latch request_to_send for new requests */
      rts_latch |= (rts_data & cic_data & door_closed) & ~carrier_attn & ~rts2_data;  // de-latch when rts2 pressed
      rts2_latch |= (rts2_data & cic_data & door_closed) & ~carrier_attn2 & ~rts_data;  // de-latch when rts pressed

      /* Don't latch requests from station in current transaction */
      rts_latch &= ~station2bit(trans_station);
      rts2_latch &= ~station2bit(trans_station);

      /* Turn off those who have lost their carrier or opened door */
      rts_latch &= cic_data;
      rts2_latch &= cic_data;
      rts_latch &= door_closed;
      rts2_latch &= door_closed;

      // Setup in-use lights for primary and optional secondary in-use lights
      on_bits    = station2bit(trans_station);
      flash_bits = rts_latch | rts_data;
      flash_bits |= ~door_closed;  // flash open doors
      flash_bits |= carrier_attn; // flash stations needing attention  (unremoved delivery)
      on_bits2    = station2bit(trans_station);
      flash_bits2 = rts2_latch | rts2_data;
      flash_bits2 |= ~door_closed;  // flash open doors
      flash_bits2 |= carrier_attn2; // flash stations needing attention  (unremoved delivery)
      if ((mainStation==SLAVE) && (param.subStaAddressing==TRUE))
      		flash_bits2 |= station2bit(diverter_station);
      else  flash_bits |= station2bit(diverter_station);

// NEED TO LOOK INTO HOW ARRIVAL_FROM WORKS
      // if main arrival active, flash inuse at who sent to main
      if (arrival_from)
      {  on_bits &= ~arrival_from;   // Not on solid
         flash_bits |= arrival_from; // On flash instead
      }

      // set the in use lights as necessary
      inUse(OFF, ~on_bits & ~flash_bits & MY_STATIONS & ~station2bit(trans_station));
      inUse(ON, on_bits);
      inUse(FLASH, flash_bits & ~station2bit(trans_station));
      inUse2(OFF, ~on_bits2 & ~flash_bits2 & MY_STATIONS & ~station2bit(trans_station));
      inUse2(ON, on_bits2);
      inUse2(FLASH, flash_bits2 & ~station2bit(trans_station));

	   // latch the arrival signal
      i = carrierArrival(MY_STATIONS);
	   if (i) latchCarrierArrival=TRUE;     // latch this value

   } else
   {  // stuff for head diverter
   	//i = di_HDArrival;
      // && (system_state==WAIT_FOR_TURNAROUND)
		if (di_HDArrival && (system_state==WAIT_FOR_TURNAROUND)) latchCarrierArrival=TRUE;     // latch this value
      rts_data=0;   // No push to send buttons
      cic_data=0;   // No carrier in chamber optics
      door_closed=0;  // No door switches
   }



}

/********************************************************/
void process_command(struct iomessage message)
{
   char wcmd, wdata;
   char ok;
   char i;
   //static char system_state, new_state;
   static char new_state;
   static unsigned long LCA_Timer;
   struct iomessage response;

   #GLOBAL_INIT
   {
      system_state=IDLE_STATE;
      new_state=system_state;
      LCA_Timer=0;
   }

   response.command=0;
   response.station=message.station;   // set initial default
   /* determine what type of command */
   switch(message.command)
   {
      case ARE_YOU_READY:
// debug to see what may be causing loss of communication
//lastcommand=message.command;
         // enable arrival interrupt / latch
         if (param.opMode == STD_REMOTE) arrivalEnable(TRUE);  // don't enable interrupt for head diverter
         response.command=ARE_YOU_READY;
         // assume ready for now
         response.data[0]=1<<(THIS_LPLC-1);
         trans_station=message.station;
         mainStation=message.data[1];  // get the main station to be used
         // Negate assumption if not ready
         if (isMyStation(message.station) && (param.opMode == STD_REMOTE))
         {  // stuff for standard remote
            rts_latch &= ~station2bit(message.station); // clear latch
            rts2_latch &= ~station2bit(message.station); // clear latch
            /* only if door closed, and (CIC or send-to-here) */
            if  ( doorClosed(station2bit(message.station))
             && ( carrierInChamber(station2bit(message.station)) || message.data[0]==DIR_SEND) )
            {  // ready
            	if (param.subStaAddressing && mainStation==SLAVE)
               {  inUse2(ON, station2bit(message.station));
               }else
               {  inUse(ON, station2bit(message.station));
            	}
            }
            else
            {  response.data[0]=0;                     // not ready
            	if (param.subStaAddressing && mainStation==SLAVE)
               		inUse2(OFF, station2bit(message.station));
	            else  inUse(OFF, station2bit(message.station));
               alert(ON, station2bit(message.station));
            }
         }
         break;

      case SET_DIVERTER:
// debug to see what may be causing loss of communication
//lastcommand=message.command;
         if (param.opMode == STD_REMOTE)
         {  // stuff for standard remote
            if (param.subStaAddressing && message.data[1]==SLAVE)
               inUse2(FLASH, station2bit(message.station));
            else
	            inUse(FLASH, station2bit(message.station));
            setDiverter(message.station);
         } else
         {  // stuff for head diverter
            setDiverter(message.data[0]);  // head diverter comes in different byte
         }
         mainStation=message.data[1];  // get the main station to be used
         param.subStaAddressing=message.data[2];
         param.blowerType = message.data[3];

         break;

      case DIVERTER_STATUS:      /* return logic of correct position */
// debug to see what may be causing loss of communication
//lastcommand=message.command;
         response.command=DIVERTER_STATUS;
         // which port dependent on opMode
         if (param.opMode == STD_REMOTE) i = message.station;
         else i = message.data[0];
         // is that port aligned? or not used?
         if ( (di_diverterPos == diverter_map[i]) || (diverter_map[i] == 0) )
         {  response.data[0]=1<<(THIS_LPLC-1); // DIVERTER_READY;
         } else
         { response.data[0]=0;            // DIVERTER_NOT_READY;
         }
         break;

      case RETURN_INPUTS:        /* return general status */
// debug to see what may be causing loss of communication
//lastcommand=message.command;
         // main includes some status info here ... pull it out
         arrival_from=message.data[0];
         new_state=message.data[1];
         // NOT USING IT: system_direction=message.data[2];

         // tell main how I am doing
         response.command=INPUTS_ARE;
         response.station=MY_STATIONS;  // return this to enlighten main

         // fill in the rest of the response based on who I am
         if (param.opMode == STD_REMOTE)
         {  // stuff for standard remote
	         // Return latched carrier arrival if state is wait_for_remote_arrival
	         if (latchCarrierArrival && system_state==WAIT_FOR_REM_ARRIVE) ok=TRUE;
	         else ok=FALSE;
            // Return the arrival signal
         	response.data[REMOTE_ARRIVE]=carrierArrival(MY_STATIONS);
            // but if it is none then send latched arrival under some conditions
            if ((response.data[REMOTE_ARRIVE]==0) && (latchCarrierArrival)
                && (system_state==WAIT_FOR_REM_ARRIVE))   response.data[REMOTE_ARRIVE]=latchCarrierArrival;
            response.data[REMOTE_CIC]=carrierInChamber(MY_STATIONS);
            response.data[REMOTE_DOOR]=doorClosed(MY_STATIONS);
            response.data[REMOTE_RTS]=rts_latch;
            response.data[REMOTE_RTS2]=rts2_latch;
         } else
         {  // stuff for head diverter
	         // Return latched carrier arrival if state is wait_for_turnaround
	         if ((latchCarrierArrival || di_HDArrival) && (system_state==WAIT_FOR_TURNAROUND)) ok=TRUE;
	         else ok=FALSE;
            // Return the arrival signal
            if (ok) response.data[REMOTE_ARRIVE]=MY_STATIONS;
            else response.data[REMOTE_ARRIVE]=0;
            response.data[REMOTE_CIC]=0;
            response.data[REMOTE_DOOR]=0; // HD has no stations  MY_STATIONS;
            response.data[REMOTE_RTS]=0;
            if (blwrError==FALSE) response.data[REMOTE_RTS2]=blowerPosition();
            else response.data[REMOTE_RTS2]=0xFF; // Blower has an error
         }
         break;

      case RETURN_EXTENDED:     /* return extended data */
// debug to see what may be causing loss of communication
//lastcommand=message.command;
          // return watchdog and powerlow counters
         response.command=RETURN_EXTENDED;
         response.data[0]=0;//watchdogCount();
         response.data[1]=0;//powerlowCount();
         response.data[2]=VERSION;
         break;

      case SET_OUTPUTS:
// debug to see what may be causing loss of communication
//lastcommand=message.command;
         if (param.opMode == STD_REMOTE)
         {  // stuff for standard remote
            /* set outputs from mainsta */
            set_remote_io(&message.data[0]);
         }
         break;

      case CLEAR_OUTPUTS:
// debug to see what may be causing loss of communication
//lastcommand=message.command;
         break;

      case SET_OPMODE:
// debug to see what may be causing loss of communication
//lastcommand=message.command;
         break;

      case SET_PARAMETERS:  // get the blower type and other parameters
// debug to see what may be causing loss of communication
//lastcommand=message.command;
			param.portMapping = message.data[0];
      	param.blowerType = message.data[1];
			writeParameterSettings();
         setDiverterMap(param.portMapping);

      	break;

      case TRANS_COMPLETE:
// debug to see what may be causing loss of communication
//lastcommand=message.command;
         arrivalEnable(FALSE);  // Disable arrival interrupt
         trans_station=0;

         if (param.opMode == STD_REMOTE)
         {  // stuff for standard remote
            alert(OFF, station2bit(message.station));
            // set arrival alert if the transaction is to here
            if (message.data[0] == DIR_SEND && isMyStation(message.station))
            {  if (message.data[1]==1)  // and Main says to set arrival alert
               { // OK to set alert
                  // REDUNDANT inUse(FLASH, station2bit(message.station));  // until no cic
                  if ((mainStation==SLAVE) && (param.subStaAddressing==TRUE))
		                  carrier_attn2 |= station2bit(message.station);  // to flash inuse
						else  carrier_attn |= station2bit(message.station);  // to flash inuse
                  arrival_alert(aaSET, message.station);
               }
            }
            else if (message.data[0] == DIR_RETURN && isMyStation(message.station))
            {  // capture the main arrival flag
            }
         } // nothing else for head diverter
         break;

      case MALFUNCTION:  // may be contributing to funky flashing
// debug to see what may be causing loss of communication
//lastcommand=message.command;
         if (param.opMode == STD_REMOTE)
         {  // stuff for standard remote only
            // turn on alarm output only
            inUse(OFF, MY_STATIONS);           // clear local i/o
            inUse2(OFF, MY_STATIONS);           // clear local i/o
            alert(OFF, MY_STATIONS);
            alarm(ON);
            arrival_alert(aaRESET, 0);
         }
         arrivalEnable(FALSE);  // Disable arrival interrupt
         rts_latch=0;
         rts2_latch=0;
         trans_station=0;
         diverter_station=0;
         response.data[0]=0;                 // clear remote i/o
         response.data[1]=0;
         response.data[2]=0;
         response.data[3]=0;
         set_remote_io(&response.data[0]);
         break;

      case RESET:
// debug to see what may be causing loss of communication
//lastcommand=message.command;
         if (param.opMode == STD_REMOTE)
         {  // stuff for standard remote only
            // Turn off all outputs
            inUse(OFF, MY_STATIONS);           // clear local i/o
            inUse2(OFF, MY_STATIONS);           // clear local i/o
            alert(OFF, MY_STATIONS);
            alarm(OFF);
            arrival_alert(aaRESET, 0);
         }
         blwrError=FALSE;       // reset blower error
         arrivalEnable(FALSE);  // Disable arrival interrupt
         /// rts_latch=0;  Try to not clear latch on reset
         trans_station=0;
         diverter_station=0;
         response.data[0]=0;                 // clear remote i/o
         response.data[1]=0;
         response.data[2]=0;
         response.data[3]=0;
         set_remote_io(&response.data[0]);
         break;
   }

   /* send the response message if any AND the query was only to me */
   if (response.command && (message.lplc==THIS_LPLC))
   {  msDelay(2); // hold off response just a bit
      //response.lplc=THIS_LPLC;
      send_response(response);
   }

   // process state change
   if (new_state != system_state)
   {  // set blower for new state
      system_state=new_state;
      blower(blowerStateTable[system_state][blwrConfig]);
   }

   return;
}

unsigned long alert_timer[8];   // for stations 1..7     ...  [0] is not used.
void arrival_alert(char func, char station)
{
   int i;

   switch (func)
   {
      case aaRESET:
       for (i=1; i<=7; i++)
       {
          alert_timer[i]=0;
          alert(OFF, station2bit(i));
       }
       break;

      case aaSET:
       if (station>=1 && station<=7)       // make sure s# is correct
       {
          alert_timer[ station ] = SEC_TIMER;
       }
       break;

      case aaTEST:
       for (i=1; i<=7; i++)     // Check each station
       {
          if (alert_timer[i])
          {
             if ( carrierInChamber( station2bit(i) ))    // || (remote_stat_alert==i) )
             {
               // Flash as necessary
               if ( (SEC_TIMER - alert_timer[i]) %20 >= 10 )
                 alert(ON, station2bit(i));
               else
                 alert(OFF, station2bit(i));
             }
             //else if (clock() = alert_timer[i] > 1)
             else if (!doorClosed( station2bit(i) ) || i==trans_station)
             {  // no carrier, door open
               // or no carrier, in transit --> reset
               alert_timer[i]=0;
               alert(OFF, station2bit(i));
               carrier_attn &= ~station2bit(i); // clear attn flag
               carrier_attn2 &= ~station2bit(i); // clear attn flag

             }
          } else
          {  carrier_attn &= ~station2bit(i); // no timer, so no flag
          	 carrier_attn2 &= ~station2bit(i); // no timer, so no flag
          }

       }
       break;
   }
}

/************************************************************/
/**************     DIGITAL I/O     *************************/
/************************************************************/
#define devIUS   0
#define devIUF   1
#define devAlert 2
#define devAlarm 3
#define dev2IUS  4
#define dev2IUF  5
// #define devDoorAlert 4

int readDigInput(char channel)
{  // returns the state of digital input 0-39
   // function supports inverted logic by assigning dio_ON and dio_OFF

   char rtnval;

   if (channel < 16)
   {  // on-board inputs
      rtnval = digIn(channel);
   }
   else
   {  // rn1100 inputs
      if (DevRN1100 != -1)
      {  if (rn_digIn(DevRN1100, channel-16, &rtnval, 0) == -1) rtnval=1; } // 1 is off
      else rtnval = 0;
   }
   // deal with logic inversion
   if (rtnval) rtnval = dio_ON;
   else        rtnval = dio_OFF;
   return rtnval;
}
int readDigBank(char bank)
{  // returns the state of digital input banks 0-3
   // banks 0-1 on Coyote; banks 2-3 on RN1100
   // function supports inverted logic by assigning dio_ON and dio_OFF

   static char rtnval[4];  // to cache previous inputs
   char returnVal;
   char temp;

   #GLOBAL_INIT
   {  rtnval[0]=0; rtnval[1]=0; rtnval[2]=0; rtnval[3]=0;
   }

   if (bank < 2)
   {  // on-board inputs
      rtnval[bank] = digBankIn(bank);
   }
   else
   {  // rn1100 inputs
      if (DevRN1100 != -1)
      {
         if (rn_digBankIn(DevRN1100, bank-1, &temp, 0) == -1) rtnval[bank]=0xFF;  // 1 is off
         else rtnval[bank]=temp;
      }
   }
   returnVal = rtnval[bank];
   // deal with logic inversion
   if (dio_OFF) returnVal ^= 0xFF;
   return returnVal;
}

void setDigOutput(int channel, int value)
{  // sets the state of digital output 0-23
   // call with logic value (0=OFF, 1=ON)
   // function is adapted to support inverted logic by assigning dio_ON and dio_OFF

   int outval;
   // check for logic inversion
   if (value) outval = dio_ON;
   else       outval = dio_OFF;

   if (channel < 8)
   {  // on-board outputs
      digOut(channel, outval);
   }
   else
   {  // rn1100 outputs
      if (DevRN1100 != -1)
         rn_digOut(DevRN1100, channel-8, outval, 0);
   }
}

/*************************************************************/
void set_remote_io(char *remotedata)
{
   /* save state of remote output request */
   remoteoutput[0]=remotedata[0];
   remoteoutput[1]=remotedata[1];
//   remoteoutput[2]=remotedata[2];  // THIS IS devAlert - DON'T TAKE FROM MAIN
   remoteoutput[2]=remotedata[2];   // Instead use remotedata[2] to drive the door alert
   remoteoutput[3]=remotedata[3];

   /* write out all outputs .. some may need to be shifted */
//   write4data(addrIUS, outputvalue[devIUS] | remoteoutput[devIUS]);
//   write4data(addrIUF, outputvalue[devIUF] | remoteoutput[devIUF]);
//   outval = ((outputvalue[devAlert] | remoteoutput[devAlert]) >> IO_SHIFT);
//   write4data(addrALT, outval);
//   write4data(addrALM, outputvalue[devAlarm] | remoteoutput[devAlarm]);

   // Write remotedata[devAlert] to output ports O5-O8
//   hv_outval &= ~DOOR_ALERT_MASK;    // turn off door alert bits
//   hv_outval = (remotedata[devAlert] & MY_STATIONS) >> IO_SHIFT;
//   hv_wr(hv_outval);

}
/******************************************************************/
char carrierInChamber(char stamask)
{  return (di_carrierInChamber << IO_SHIFT) & stamask; }
/******************************************************************/
char doorClosed(char stamask)
{  // Note: input is normally high on closed.
   char indata;
   indata = di_doorClosed;
   return ((indata << IO_SHIFT) & stamask);
}
/******************************************************************/
char carrierArrival(char stamask)
{  return (di_carrierArrival << IO_SHIFT) & stamask; }

/******************************************************************/
char requestToSend(char stamask)
{
   char indata;
   indata = di_requestToSend;
   return ((indata << IO_SHIFT) & stamask);
}
char requestToSend2(char stamask)
{
   char indata;
   indata = di_requestToSend2;
   return ((indata << IO_SHIFT) & stamask);
}
/******************************************************************/
void inUse(char how, char station_b)
{
   if (how == ON)
   {  /* solid on, flash off */
      outputvalue[devIUS] |= station_b;
      outputvalue[devIUF] &= ~station_b;
   }

   if (how == OFF)
   {  /* solid off, flash off */
      outputvalue[devIUS] &= ~station_b;
      outputvalue[devIUF] &= ~station_b;
   }

   if (how == FLASH)
   {  /* solid off, flash on */
      outputvalue[devIUS] &= ~station_b;
      outputvalue[devIUF] |= station_b;
   }

   return;
}
void inUse2(char how, char station_b)
{
   if (how == ON)
   {  /* solid on, flash off */
      outputvalue[dev2IUS] |= station_b;
      outputvalue[dev2IUF] &= ~station_b;
   }

   if (how == OFF)
   {  /* solid off, flash off */
      outputvalue[dev2IUS] &= ~station_b;
      outputvalue[dev2IUF] &= ~station_b;
   }

   if (how == FLASH)
   {  /* solid off, flash on */
      outputvalue[dev2IUS] &= ~station_b;
      outputvalue[dev2IUF] |= station_b;
   }

   return;
}
/******************************************************************/
void alert(char how, char station_b)
{
   if (how == ON) outputvalue[devAlert] |= station_b;
   if (how == OFF) outputvalue[devAlert] &= ~station_b;

   //outval = ((outputvalue[devAlert] | remoteoutput[devAlert]) >> IO_SHIFT);
   //write4data(addrALT, outval);
   //do_alert(outval, how);
   // OUTPUTS WRITTEN IN SYSTEM LOOP CALL TO updateOutputs();

   return;
}
/******************************************************************/
void alarm(char how)
{
   // outputvalue is checked in the inUse function to turn alarm on/off
   outputvalue[devAlarm] = how;

   return;
}
/******************************************************************/
unsigned long diverter_start_time;     // these used primarily by diverter functions
char diverter_setting;
char diverter_attention;
void setDiverter(char station)
{  /* Controls the setting of diverter positions
      Return from this routine is immediate.  If diverter is not
      in position, it is turned on and a timer started.

      You MUST repeatedly call processDiverter() to complete processing
      of the diverter control position
   */

   /* use mapping from station to diverter position */

   if ((station>0) && (station<9))     // Valid station #
   {
      diverter_setting = diverter_map[station];    // mapped setting

      // if position<>ANY (any=0) and not in position
      if ((diverter_setting>0) && (diverter_setting!=di_diverterPos))
      {
         /* turn on diverter and start timer */
         do_diverter(ON);

         diverter_start_time = MS_TIMER;
         diverter_attention = TRUE;
         diverter_station=station;
      }
   }
   return;
}
/******************************************************************/
void processDiverter()
{  /* Poll type processing of diverter control system */
   /* Allows other processes to be acknowleged when setting diverter */

   if (diverter_attention)
   {
      if ((diverter_setting == di_diverterPos) || Timeout(diverter_start_time, DIVERTER_TIMEOUT))
      {
         // turn off diverter and clear status
         do_diverter(OFF);
         diverter_attention = FALSE;
         diverter_station=0;
      }
   }
}
void showactivity()
{
   // update active processor signal
   ledOut(0, (MS_TIMER %500) < 250);  // on fixed frequency
   ledOut(1, (MS_TIMER %500) > 250);  // off fixed frequency
   toggleLED(2);                      // toggle each call
}
void toggleLED(char LEDDev)
{
   static char LEDState[4];

   // if LEDDev not 0..3 then initialize LED states off
   if (LEDDev > 3)
   {  LEDState[0]=0; LEDState[1]=0; LEDState[2]=0; LEDState[3]=0;
   }
   else
   {
      LEDState[LEDDev] ^= 1;               // toggle LED state on/off
      ledOut(LEDDev, LEDState[LEDDev]);    // send LED state
   }
}

void maintenance(void)
{  // handle all regularly scheduled calls
	// use of static CHAR was causing PA4 RS485 transmitter to enable without reason ... static INT works ok.
   static int out_alert, out_inuse, out_inuse2, out_doorAlert;
   char i;

   hitwd();                // hit the watchdog timer
   showactivity();
   //rn_keyProcess(DevRN1600, 0);  // process keypad device

   // process command communications
   //tcp_tick(NULL);
   //receive_command();

   // process flashing inUse lights
   // out_alert = ((outputvalue[devAlert] | remoteoutput[devAlert]) >> IO_SHIFT);
   out_alert = ((outputvalue[devAlert]) >> IO_SHIFT);
   out_doorAlert = (remoteoutput[devAlert] >> IO_SHIFT);

   // flash on
   if ((MS_TIMER %500) < 200)
   {  out_inuse = (outputvalue[devIUF] | outputvalue[devIUS]) >> IO_SHIFT;
		out_inuse2 = (outputvalue[dev2IUF] | outputvalue[dev2IUS]) >> IO_SHIFT;
   }
	// or flash off
   else
   {	out_inuse = outputvalue[devIUS] >> IO_SHIFT;
   	out_inuse2 = outputvalue[dev2IUS] >> IO_SHIFT;
   }

   // Write out alerts and inUse light
   // Check for and setup point to point configuration
   #if REMOTE_TYPE == RT_POINT2POINT
	   do_arrivalAlert(0, out_alert & 1);
	   do_inUseLight(0, out_inuse & 1);
	   do_doorAlert(0, out_doorAlert & 1);
   #else
	   for (i=0; i<4; i++)
	   {  do_arrivalAlert(i, out_alert & (1<<i));
	      do_inUseLight(i, out_inuse & (1<<i));
	      do_inUse2Light(i, out_inuse2 & (1<<i));
	      do_doorAlert(i, out_doorAlert & (1<<i));
	   }
   #endif



   // Process alarm output
   //do_alarm(outputvalue[devAlarm]);

}

/******************************************************************/
// Blower Processing Routines - supports both standard and APU blowers
/******************************************************************/
// Interface definition
// char blwrConfig;     // to become a parameter from eeprom
// blwrConfig 0 = Standard blower
// blwrConfig 1 = High capacity APU blower
// #define blwrOFF  0
// #define blwrIDLE 1
// #define blwrVAC  2
// #define blwrPRS  3
// void initBlower(void);
// void blower(char blowerOperatingValue);  // use blwrOFF, blwrIDLE, blwrVAC, blwrPRS
// char processBlower(void);
// char blowerPosition(void);

char blower_mode, blower_limbo, last_shifter_pos, lastDir;
unsigned long blower_timer;

void initBlower()
{   // trys to find any shifter position, then goes to idle
    unsigned long mytimer;

    blwrConfig = 1; // Turnaround configuration

    // Clear global blower variables
    last_shifter_pos=0;
    lastDir=0;
    blower_limbo=FALSE;
	 blwrError=FALSE;

    // turn off all outputs
    do_blower(OFF);
    do_blowerVac(OFF);
    do_blowerPrs(OFF);

    // remainder of initialization is for APU blowers only
    if (param.blowerType == blwrType_APU)
    {
	    // if not in any position, try to find any position
	    if (blowerPosition() == 0)
	    {  // hunt for any position
	       do_blowerPrs(ON);
	       mytimer=MS_TIMER;
	       while (Timeout(mytimer, 5000)==FALSE && blowerPosition()==0) hitwd();
	       if (blowerPosition()==0)
	       {  // still not found...so go the other way
	          do_blowerPrs(OFF);
	          do_blowerVac(ON);
	          mytimer=MS_TIMER;
	          while (Timeout(mytimer, 5000)==FALSE && blowerPosition()==0) hitwd();
	          do_blowerVac(OFF);
             if (blowerPosition()==0) blwrError = TRUE;  // capture unknown position error
	       }
	    }

	    // after all that, now command to goto idle
	    blower(blwrIDLE);
	 }
}
void blower(char request)
{  // operates both standard blowers and APU blowers
   // sets the direction of the blower shifter
   // use  blwrVAC, blwrPRS, blwrIDLE, or OFF
   char hv_save;
   char how;
   static char lastHow;

   #GLOBAL_INIT
   {  blwrConfig = 1; // Turnaround configuration
      lastHow = 0;
   }

   // Handling of standard blower type
   if (param.blowerType == blwrType_STD)
   {  // No such state as idle in standard blowers so map to OFF
   	if (request==blwrIDLE) request=blwrOFF;
	   how = request;

	   // make sure correct parameter is used.  anything but VAC and PRS is OFF
	   if ((how != blwrVAC) && (how != blwrPRS)) how = blwrOFF;

	   // if going from one on-state to the other on-state then turn off first
	   if ((how != blwrOFF) && (lastHow != blwrOFF) && (how != lastHow))
	   {  // can't run in both directions at the same time
	      do_blowerPrs(OFF);
	      do_blowerVac(OFF);
	      msDelay(100);                   /* wait a little while */
	   }

	   /* turn on appropriate bit */
	   if (how == blwrPRS)      do_blowerPrs(ON);
	   else if (how == blwrVAC) do_blowerVac(ON);
	   else { do_blowerPrs(OFF);
	          do_blowerVac(OFF);
	        }
	   // Add alternate blower on/off control per Joe request on 10-Jul-07
   	if (how != blwrOFF) do_blower(ON);
		else do_blower(OFF);

	   // remember last setting
	   lastHow = how;
   } // end of standard blower

   // Handling of APU blower type
   else if ((param.blowerType == blwrType_APU) && (request != lastHow))
   {
	   // store in local work space
	   blower_mode=request;
	   blower_limbo=FALSE;
      lastHow=request;

	   /* clear previous state */
	   // hv_save=output_buffer;
	   // turn off shifters
	   do_blowerPrs(OFF);
	   do_blowerVac(OFF);

	   // CW for Pressure to Idle or Any to Vacuum
	   // CCW for Vacuum to Idle or Any to Pressure
	   if (blower_mode == blwrVAC) { do_blowerVac(ON); lastDir=blwrVAC; }
	   else if (blower_mode == blwrPRS) { do_blowerPrs(ON); lastDir=blwrPRS; }
	   else if (blower_mode == blwrIDLE)
	   {  if (blowerPosition() == blwrPRS) { do_blowerVac(ON); lastDir=blwrVAC; }
	      else if (blowerPosition() == blwrVAC) { do_blowerPrs(ON); lastDir=blwrPRS; }
	      else if (blowerPosition() == 0)
	      {
	          // go to idle but don't know which way
	          if (lastDir==blwrVAC) { do_blowerVac(ON); blower_limbo=TRUE; lastDir=blwrVAC; }
	          else if (lastDir==blwrPRS) { do_blowerPrs(ON); blower_limbo=TRUE; lastDir=blwrPRS; }
	          else
	          {  // use last position to know which way to go
	             blower_limbo = TRUE;       // incomplete operation
	             if (last_shifter_pos==blwrPRS) { do_blowerVac(ON); lastDir=blwrVAC; }
	             else if (last_shifter_pos==blwrVAC) { do_blowerPrs(ON); lastDir=blwrPRS; }
	             else blower_limbo=FALSE;  // idle to idle is ok to leave alone
	          }
	      } // else go-idle and already in idle position
	   } else if (blower_mode == OFF) do_blower(OFF);  // power off

	   blower_timer = MS_TIMER;
   }

   return;
}
char processBlower()
{   // call repeatedly to handle process states of the blower
    // returns non-zero when shifter or blower error
    char rtnval;

    rtnval=0;  // assume all is good

    // Remainder only for APU blowers
    if (param.blowerType == blwrType_APU)
    {

	    if (blower_mode==OFF) return rtnval;  // nothing happening, go home.
	    if (blower_mode==ON) return rtnval;   // running ... nothing to do

	    // check for idled blower timeout
	    if ((blower_mode==blwrIDLE) && (last_shifter_pos == blwrIDLE) && (lastDir==0) )
	    {  // turn off idle'd blower after 2 minutes
	       if (MS_TIMER - blower_timer > 120000)
	       {  // turn off all blower outputs
	          do_blowerPrs(OFF);
	          do_blowerVac(OFF);
	          do_blower(OFF);
	          blower_mode=OFF;
	          lastDir=0;
	       }
	       return rtnval;
	    }

	    // check for incomplete change of direction and reset shifter outputs.
	    // if was in limbo, and now in a known position, reset shifter
	    if (blowerPosition() && blower_limbo) blower(blower_mode);

	    // if in position  .. but only the first time FIX.
	    if (blower_mode == blowerPosition())
	    {  // turn off shifter, turn on blower
	       do_blowerPrs(OFF);
	       do_blowerVac(OFF);
	       lastDir=0;

	        // if going for idle position, mode is not ON ... just idle
	        if (blower_mode != blwrIDLE)
	        {  blower_mode = ON;          // generic ON state
	           do_blower(ON);
	        }
	        blower_timer=MS_TIMER;  // use also for blower idle time
	    }
	    else if (MS_TIMER - blower_timer > 12000)
	    {  // timeout ... shut off all outputs
	       do_blowerPrs(OFF);
	       do_blowerVac(OFF);
	       lastDir=0;
	       blower_mode=OFF;
	       rtnval=1;          // set error code
          blwrError=TRUE;
	    }
    }

    return rtnval;

}
char blowerPosition()
{  // returns the current position of the blower shifter
   // also keeps track of the last valid shifter position
   char rtnval, inval;
   rtnval=0;
   if (di_shifterPosVac) rtnval=blwrVAC;
   if (di_shifterPosPrs) rtnval=blwrPRS;
   if (di_shifterPosIdle) rtnval=blwrIDLE;
   if (rtnval) last_shifter_pos=rtnval;
   return rtnval;
}

/********************************************************
   Communication I/O drivers
*********************************************************/
/* Initialize buffers and counters */
#define BAUD_RATE 19200
#define CMD_LENGTH   11
#define RCV_TIMEOUT  2
#define rbuflen      30
#define sbuflen      5
char rbuf[rbuflen], sbuf[sbuflen];
char bufstart; //rcc

void disable485whenDone(void)
{
   while (serDwrUsed());          // wait for all bytes to be transmitted
   while (RdPortI(SDSR) & 0x0C);  // wait for last byte to complete
   serDrdFlush();                 // flush the read buffer
   ser485Rx();                    // disable transmitter
}
/********************************************************/
void enable_commands()
{  // open serial port D
   serDopen(BAUD_RATE);
   ser485Rx();       // enable the receiver
   serDrdFlush();    // flush the read buffer
}
/********************************************************/
void send_response(struct iomessage message)
{  /* Transmits a message/command to the main system.
      Command string defined as:
      <STX> <lplc> <Command> <Station> <Data0..3> <ETX> <CHKSUM> */

   char i;
   char cmdstr[CMD_LENGTH];
   char cmdlen;
   char rcvbuf[CMD_LENGTH];
   char rcvlen;
   unsigned long timeout, cmdsent;
   cmdlen=CMD_LENGTH;

   // enable transmitter and send
   ser485Tx();

   /* formulate the full command string */
   cmdstr[0] = STX;
   cmdstr[1] = THIS_LPLC;
   cmdstr[2] = message.command;
   cmdstr[3] = message.station;
   for (i=0; i<NUMDATA; i++) cmdstr[i+4]=message.data[i];
   cmdstr[CMD_LENGTH-2] = ETX;
   cmdstr[CMD_LENGTH-1] = 0;
   for (i=0; i<CMD_LENGTH-1; i++)
      cmdstr[CMD_LENGTH-1] += cmdstr[i];  /* calculate checksum */

   // send it
   cmdlen = serDwrite(cmdstr, CMD_LENGTH);
   if (cmdlen != CMD_LENGTH) printf("Send command failed, only sent %d chars \n", cmdlen);

   disable485whenDone();

}


/********************************************************/
char get_command(struct iomessage *message)
{
/* Repeatedly call this function to process incoming commands
   efficiently.
*/
   int charsinbuf;
   char msg_address;  //worklen,
   char rtnval, chksum, i;
   unsigned long t1, t2;
   char tossed[50];


   // charsinbuf = rbuflen-rcc;
   // worklen = charsinbuf-bufstart;
   rtnval=FALSE;     /* assume none for now */

   // align frame to <STX>
   i=0;
   t1=MS_TIMER;
   while ((serDrdUsed() > 0) && (serDpeek() != STX)) { tossed[i]=serDgetc(); i++; }
   t2=MS_TIMER;
   if (i>0)
   {  //printf("%ld %ld tossed %d: ",t1, t2, i);
      //while (i>0) { i--; printf(" %d", tossed[i]); }
      //printf("\n");
   }

   // if at least 1 command in buffer then get them
   charsinbuf=0;
   if (serDrdUsed() >= CMD_LENGTH)
      charsinbuf = serDread(rbuf, CMD_LENGTH, RCV_TIMEOUT);

   bufstart = 0;
   if (charsinbuf==CMD_LENGTH)  /* all characters received */
   {
      /* verify STX, ETX, checksum then respond */
      if ((rbuf[bufstart] == STX) && (rbuf[bufstart+CMD_LENGTH-2] == ETX))
      {
         // enable transmitter if message is addressed to me only
         if (msg_address==THIS_LPLC) ser485Tx();

         /* check checksum */
         chksum=0;
         for (i=0; i<CMD_LENGTH-1; i++) chksum+=rbuf[bufstart+i];
         if (chksum != rbuf[bufstart+CMD_LENGTH-1])
         {  // no good, send NAK
            sbuf[0]=NAK;
            rtnval=FALSE;
         }
         else
         {  /* looks good, send ACK */
            sbuf[0]=ACK;
            rtnval=TRUE;
         }
         msg_address = rbuf[bufstart+1];
         // send response if message is addressed to me only
         if (msg_address==THIS_LPLC)
         {
            // enable transmitter and send
            ser485Tx();
            serDwrite(sbuf, 1);
            disable485whenDone();
         }

         // If this message for me OR everyone then process it.
         if ((msg_address==THIS_LPLC) || (msg_address==ALL_DEVICES))
         {  // message for me (and possibly others)
            /* return the command for processing */
            message->lplc=msg_address;
            message->command=rbuf[bufstart+2];
            message->station=rbuf[bufstart+3];
            for (i=0; i<NUMDATA; i++) message->data[i]=rbuf[i+bufstart+4];

         } else rtnval=FALSE;  // command not for me!

         // Maybe shouldn't flush the buffer
         // serDrdFlush(); // flush the read buffer
      }
   }
   //else
   //{ printf("missing chars %d\n", charsinbuf); serDrdFlush(); }
   return rtnval;
}
/******************************************************************/
char isMyStation(char station)
{       return (station2bit(station) & MY_STATIONS);
}
/******************************************************************/
char station2bit(char station)
{  /* Converts the station number assignment to an equivalent
      bit value.  ie. station 3 -> 0100 (=4) .. same as 2^(sta-1)
      NOTE: Returns 0 if station is not 1..8  */

   if (station) return 1 << (station-1);
   return 0;
}
/******************************************************************/
char bit2station(char station_b)
{  /* Converts a bit assignment to the bit number value
      ie. 0100 -> station 3.
NOTE: Returns 0 if more than 1 station bit is active */

   char stanum, i;
   stanum = 0;

   for (i=0; i<8; i++)
   {
      if (1<<i == station_b) stanum=i+1;
   }
   return stanum;
}

void msDelay(unsigned int delay)
{
   auto unsigned long start_time;
   start_time = MS_TIMER;
   if (delay < 500) while( (MS_TIMER - start_time) <= delay );
   else while( (MS_TIMER - start_time) <= delay ) hitwd();
}

char Timeout(unsigned long start_time, unsigned long duration)
{
   return ((MS_TIMER - start_time) < duration) ? FALSE : TRUE;
}

/*******************************************************/
// WATCHDOG AND POWER-LOW RESET COUNTERS
/*******************************************************/
char valid_resets;     // at myxdata+0
char watchdog_resets;  // at myxdata+1
char powerlow_resets;  // at myxdata+2
//xdata myxdata[10];

/*******************************************************/
char watchdogCount() { return watchdog_resets; }
char powerlowCount() { return powerlow_resets; }
/*******************************************************/
void incrementWDCount()
{
   watchdog_resets++;
   //root2xmem( &watchdog_resets, myxdata+1, 1);
}
/*******************************************************/
void incrementPLCount()
{
   powerlow_resets++;
   //root2xmem( &powerlow_resets, myxdata+2, 1);
}

/*******************************************************/
void loadResetCounters()
{
   // read valid_resets and check
   //xmem2root( myxdata, &valid_resets, 1);
   if (valid_resets != 69)
   {  // set to zero and mark valid
      watchdog_resets=0;
      //root2xmem( &watchdog_resets, myxdata+1, 1);
      powerlow_resets=0;
      //root2xmem( &powerlow_resets, myxdata+2, 1);
      valid_resets=69;
      //root2xmem( &valid_resets, myxdata, 1);
   } else
   {
      // Read watchdog and power-low counters
      //xmem2root( myxdata+1, &watchdog_resets, 1);
      //xmem2root( myxdata+2, &powerlow_resets, 1);
   }
}
int readParameterSettings(void)
{  // Read the parameter block param
   int rtn_code;
   rtn_code = readUserBlock(&param, 0, sizeof(param));
   return rtn_code;
}
int writeParameterSettings(void)
{  // Write the parameter block param
   int rtn_code;
   rtn_code = writeUserBlock(0, &param, sizeof(param));
   return rtn_code;
}

